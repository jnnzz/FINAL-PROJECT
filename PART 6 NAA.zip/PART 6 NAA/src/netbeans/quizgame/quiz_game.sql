-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2024 at 09:49 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz_game`
--

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question_text` varchar(255) NOT NULL,
  `option_a` varchar(100) DEFAULT NULL,
  `option_b` varchar(100) DEFAULT NULL,
  `option_c` varchar(100) DEFAULT NULL,
  `option_d` varchar(100) DEFAULT NULL,
  `correct_option` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`) VALUES
(1, 'What is the capital of France?', 'Paris', 'London', 'Berlin', 'Madrid', 'A'),
(2, 'What is 2 + 2?', '3', '4', '5', '6', 'B'),
(3, 'Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'B'),
(7, 'What is the largest ocean on Earth?', 'Atlantic', 'Indian', 'Southern', 'Pacific', 'D'),
(8, 'What year did World War II end?', '1942', '1943', '1944', '1945', 'D'),
(9, 'Who wrote \"Romeo and Juliet\"?', 'Charles Dickens', 'William Shakespeare', 'Jane Austen', 'Mark Twain', 'B'),
(10, 'What is the chemical symbol for water?', 'H2O', 'O2', 'CO2', 'HO2', 'A'),
(11, 'How many continents are there?', '5', '6', '7', '8', 'C'),
(12, 'Which animal is known as the \"King of the Jungle\"?', 'Tiger', 'Elephant', 'Lion', 'Cheetah', 'C'),
(13, 'What is the smallest prime number?', '0', '1', '2', '3', 'C'),
(14, 'Who was the first president of the United States?', 'Thomas Jefferson', 'Abraham Lincoln', 'George Washington', 'John Adams', 'C'),
(15, 'What is the capital of Japan?', 'Kyoto', 'Tokyo', 'Osaka', 'Hiroshima', 'B'),
(16, 'How many sides does a hexagon have?', '5', '6', '7', '8', 'B'),
(17, 'Which planet is known for its rings?', 'Jupiter', 'Mars', 'Saturn', 'Uranus', 'C'),
(18, 'What is the tallest mountain in the world?', 'K2', 'Kilimanjaro', 'Everest', 'Denali', 'C'),
(19, 'What is the currency of Japan?', 'Yuan', 'Won', 'Yen', 'Ringgit', 'C'),
(20, 'What element does \"O\" represent on the periodic table?', 'Osmium', 'Oxygen', 'Opium', 'Ozone', 'B'),
(21, 'Which country is known as the Land of the Rising Sun?', 'China', 'Thailand', 'Japan', 'South Korea', 'C'),
(22, 'What is the capital of Canada?', 'Vancouver', 'Ottawa', 'Toronto', 'Montreal', 'B'),
(23, 'What year did the Titanic sink?', '1910', '1912', '1914', '1916', 'B'),
(24, 'What is the chemical symbol for gold?', 'Au', 'Ag', 'Fe', 'Hg', 'A'),
(25, 'Which animal is known to have the longest lifespan?', 'Elephant', 'Blue Whale', 'Tortoise', 'Parrot', 'C'),
(26, 'What is the largest planet in our solar system?', 'Earth', 'Saturn', 'Jupiter', 'Neptune', 'C'),
(27, 'Who painted the Mona Lisa?', 'Vincent van Gogh', 'Claude Monet', 'Leonardo da Vinci', 'Pablo Picasso', 'C'),
(28, 'Which country has the longest coastline?', 'Australia', 'USA', 'Canada', 'Russia', 'C'),
(29, 'What is the tallest building in the world?', 'Shanghai Tower', 'Empire State Building', 'Burj Khalifa', 'Taipei 101', 'C'),
(30, 'What is the main ingredient in guacamole?', 'Tomato', 'Avocado', 'Pepper', 'Onion', 'B'),
(31, 'Which sport is known as \"the beautiful game\"?', 'Cricket', 'Football', 'Basketball', 'Tennis', 'B'),
(32, 'Who discovered penicillin?', 'Marie Curie', 'Alexander Fleming', 'Louis Pasteur', 'Joseph Lister', 'B'),
(33, 'What is the currency of the United Kingdom?', 'Euro', 'Pound Sterling', 'Dollar', 'Yuan', 'B'),
(34, 'What is the hardest natural substance on Earth?', 'Gold', 'Diamond', 'Iron', 'Quartz', 'B'),
(35, 'What is the official language of Brazil?', 'Spanish', 'Portuguese', 'English', 'French', 'B'),
(36, 'Which famous scientist developed the theory of relativity?', 'Isaac Newton', 'Galileo Galilei', 'Albert Einstein', 'Nikola Tesla', 'C');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
